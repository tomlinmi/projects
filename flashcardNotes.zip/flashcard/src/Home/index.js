import React from "react";
import DeckList from "../Deck/List";

function Home() {
  return (
    <div className="Home container">
      <DeckList />
    </div>
  );
}

export default Home;